/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.messageapp.Message;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class MessageTest {
    
       // Test for valid message creation
    @Test
    public void testValidMessageCreation() {
        Message msg = new Message("+27712345678", "Hi", 1);
        assertNotNull(msg.messageId);
        assertEquals("+27712345678", msg.recipient);
        assertEquals("Hi", msg.message);
        assertTrue(msg.messageHash.contains("HI"));
    }

    // Test for invalid recipient format
    @Test
    public void testInvalidRecipientThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Message("0712345", "Hello", 1);
        });
        assertTrue(exception.getMessage().contains("Invalid recipient format"));
    }

    // Test for message length exceeding the limit
    @Test
    public void testMessageTooLong() {
        String longMessage = "A".repeat(251); // Generate a string longer than 250 characters
        Message msg = new Message("+27712345678", longMessage, 1);
        assertEquals("❌ Message too long. Reduce it to 250 characters.", msg.message);
    }

    // Test for moderate message length warning
    @Test
    public void testMessageModeratelyLong() {
        String midMessage = "A".repeat(60); // Generate a string between 50 and 250 characters
        Message msg = new Message("+27712345678", midMessage, 1);
        assertEquals("❌ Please enter a message of less than 50 characters.", msg.message);
    }

    // Test for valid short message
    @Test
    public void testValidShortMessage() {
        Message msg = new Message("+27712345678", "Short message", 1);
        assertEquals("Short message", msg.message);  // Check that the message is correctly stored
    }
}