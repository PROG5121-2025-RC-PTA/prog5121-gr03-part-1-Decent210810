/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.messageapp;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;
public class MessageApp {

    public static void main(String[] args) {
       
     Scanner scanner = new Scanner(System.in);
  MessageHolder messageHolder = new MessageHolder();
        int numMessagesSent = 0;
        boolean isLoggedIn = false;

        System.out.println("Welcome to QuickChat!");

        // Login System
        while (!isLoggedIn) {
            System.out.print("Enter username: ");
            String username = scanner.nextLine().trim();
            System.out.print("Enter password: ");
            String password = scanner.nextLine().trim();

            if (username.equals("Engetelo Nukeri") && password.equals("210810@Dee")) {
                isLoggedIn = true;
                System.out.println("✅ Login successful!");
            } else {
                System.out.println("❌ Incorrect username or password. Try again.");
            }
        }

        // Ask User If They Want to Start or Exit
        System.out.println("\nDo you want to:");
        System.out.println("1) Start sending messages");
        System.out.println("2) Exit QuickChat");

        int initialChoice = scanner.nextInt();
        scanner.nextLine();

        if (initialChoice == 2) {
            System.out.println("👋 Goodbye!");
            scanner.close();
            return;
        }

        boolean running = true;
        while (running) {
            System.out.println("\nSelect an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show Recently Sent Messages");
            System.out.println("3) Quit");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter number of messages to send: ");
                    int numMessages = scanner.nextInt();
                    scanner.nextLine();

                    for (int i = 0; i < numMessages; i++) {
                        System.out.print("Enter recipient number: ");
                        String recipient = scanner.nextLine();
                        System.out.print("Enter your message: ");
                        String message = scanner.nextLine();

                        try {
                            Message newMessage = new Message(recipient, message, ++numMessagesSent);

                            System.out.println("\nChoose an option:");
                            System.out.println("1) Send Message");
                            System.out.println("2) Disregard Message");
                            System.out.println("3) Store Message");

                            int messageChoice = scanner.nextInt();
                            scanner.nextLine();

                            switch (messageChoice) {
                                case 1:
                                    messageHolder.sendMessage(newMessage);
                                    messageHolder.showMessageDetails(newMessage);
                                    break;
                                case 2:
                                    messageHolder.disregardMessage(newMessage);
                                    break;
                                case 3:
                                    messageHolder.storeMessage(newMessage);
                                    break;
                                default:
                                    System.out.println("❌ Invalid option.");
                            }
                        } catch (IllegalArgumentException e) {
                            System.out.println(e.getMessage());
                            i--; // retry the message if invalid
                        }
                    }
                    break;

                case 2:
                    if (messageHolder.sentMessages.isEmpty()) {
                        System.out.println("Feature coming soon.");
                    } else {
                        System.out.println("Recently Sent Messages:");
                        for (Message msg : messageHolder.sentMessages) {
                            System.out.println("Message ID: " + msg.messageId);
                            System.out.println("Recipient: " + msg.recipient);
                            System.out.println("Message: " + msg.message);
                            System.out.println("------------");
                        }
                    }
                    break;

                case 3:
                    System.out.println("👋 Goodbye!");
                    messageHolder.displayTotalMessagesSent();
                    running = false;
                    break;

                default:
                    System.out.println("❌ Invalid choice.");
            }
        }

        scanner.close();
        System.out.println("✅ BUILD SUCCESSFUL. Thank you for using our chat app, we hope to see you again. Have a lovely day!!: ");
    }
}
