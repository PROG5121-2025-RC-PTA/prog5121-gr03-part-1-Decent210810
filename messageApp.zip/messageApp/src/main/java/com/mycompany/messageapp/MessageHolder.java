/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.messageapp;

/**
 *
 * @author RC_Student_lab
 */
import java.util.ArrayList;
import java.util.List;

public class MessageHolder {
    
     public List<Message> sentMessages = new ArrayList<>();
    public List<Message> storedMessages = new ArrayList<>();
    public List<Message> disregardedMessages = new ArrayList<>();
    public List<String> messageHashes = new ArrayList<>();
    public List<String> messageIds = new ArrayList<>();
    public int totalMessagesSent = 0;

    public void sendMessage(Message message) {
        sentMessages.add(message);
        messageHashes.add(message.messageHash);
        messageIds.add(message.messageId);
        totalMessagesSent++;
        System.out.println("Message successfully sent.");
    }

    public void storeMessage(Message message) {
        storedMessages.add(message);
        messageHashes.add(message.messageHash);
        messageIds.add(message.messageId);
        totalMessagesSent++;
        System.out.println("Message successfully stored.");
    }

    public void disregardMessage(Message message) {
        disregardedMessages.add(message);
        System.out.println("Message disregarded.");
    }

    public void displayTotalMessagesSent() {
        System.out.println("Total messages sent: " + totalMessagesSent);
    }

    public void showMessageDetails(Message message) {
        System.out.println("Message ID: " + message.messageId);
        System.out.println("Recipient: " + message.recipient);
        System.out.println("Message: " + message.message);
    }

    public void showRecentMessages() {
        if (sentMessages.isEmpty()) {
            System.out.println("Feature coming soon.");
        } else {
            System.out.println("Recently Sent Messages:");
            for (Message msg : sentMessages) {
                System.out.println("Message ID: " + msg.messageId);
                System.out.println("Recipient: " + msg.recipient);
                System.out.println("Message: " + msg.message);
                System.out.println("------------");
            }
        }
    }
}