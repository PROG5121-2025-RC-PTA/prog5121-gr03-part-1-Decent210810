/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.messageapp;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Random;

public class Message {
    
    public String messageId;
    public int numMessagesSent;
    public String recipient;
    public String message;
    public String messageHash;

    // Constructor: Creates a message with basic validation
    public Message(String recipient, String message, int numMessagesSent) {
        if (!isValidRecipient(recipient)) {
            throw new IllegalArgumentException("❌ Invalid recipient format. Must start with '+' and contain 10-13 digits.");
        }

        this.messageId = createMessageId();
        this.numMessagesSent = numMessagesSent;
        this.recipient = recipient;
        this.message = checkMessageLength(message);
        this.messageHash = createMessageHash();
    }

    // Creates a unique random message ID
    public String createMessageId() {
        Random random = new Random();
        int randomNum = 1000000000 + random.nextInt(900000000); // Generates a random 10-digit number
        return String.valueOf(randomNum);
    }

    // Validates recipient number format (must start with "+" and be 10-13 digits)
    public boolean isValidRecipient(String recipient) {
        return recipient.matches("\\+?\\d{10,13}");
    }

    // Ensures the message isn't too long
    private String checkMessageLength(String msg) {
        if (msg.length() > 250) {
            return "❌ Message too long. Reduce it to 250 characters.";
        } else if (msg.length() > 50) {
            return "❌ Please enter a message of less than 50 characters.";
        }
        return msg;
    }

    // Generates a tracking hash based on the message details (formatted in all caps)
    public String createMessageHash() {
        String[] words = message.split(" ");

        // Ensure we have enough words before creating a hash
        if (words.length < 2) {
            return messageId.substring(0, 2) + ":" + numMessagesSent + ":" + message.toUpperCase();
        }

        return messageId.substring(0, 2) + ":" + numMessagesSent + ":" + words[0].toUpperCase() + words[words.length - 1].toUpperCase();
    }
}