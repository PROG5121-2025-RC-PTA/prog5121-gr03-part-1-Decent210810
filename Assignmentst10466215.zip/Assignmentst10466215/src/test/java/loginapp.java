/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author nuker
 */
public class loginapp {
    
    public loginapp() {
    }
      public void testUsernameWithUnderscore() {
       

public class LoginTest {
    Login loginApp = new Login();

    @Test
    void testCheckUserName_Valid() {
        assertTrue(loginApp.checkUserName("user_"), "Username should be valid.");
    }

    @Test
    void testCheckUserName_Invalid() {
        assertFalse(loginApp.checkUserName("user123"), "Username should be invalid.");
    }

    @Test
    void testCheckPasswordComplexity_Valid() {
        assertTrue(loginApp.checkPasswordComplexity("StrongP@ss1"), "Password should be valid.");
    }

    @Test
    void testCheckPasswordComplexity_Invalid() {
        assertFalse(loginApp.checkPasswordComplexity("password"), "Password should be invalid.");
    }

    @Test
    void testCheckCellPhoneNumber_Valid() {
        assertTrue(loginApp.checkCellPhoneNumber("+27839123456"), "Cell phone number should be valid.");
    }

    @Test
    void testCheckCellPhoneNumber_Invalid() {
        assertFalse(loginApp.checkCellPhoneNumber("0839123456"), "Cell phone number should be invalid.");
    }

    @Test
    void testRegisterUser_Success() {
        String result = loginApp.registerUser("user_", "StrongP@ss1", "+27839123456");
        assertEquals("User successfully registered.", result);
    }

    @Test
    void testRegisterUser_Fail_Username() {
        String result = loginApp.registerUser("user123", "StrongP@ss1", "+27839123456");
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", result);
    }

    @Test
    void testRegisterUser_Fail_Password() {
        String result = loginApp.registerUser("user_", "password", "+27839123456");
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", result);
    }

    @Test
    void testRegisterUser_Fail_CellNumber() {
        String result = loginApp.registerUser("user_", "StrongP@ss1", "0839123456");
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.", result);
    }

    @Test
    void testLoginUser_Success() {
        loginApp.registerUser("user_", "StrongP@ss1", "+27839123456");
        assertTrue(loginApp.loginUser("user_", "StrongP@ss1"), "Login should be successful.");
    }

    @Test
    void testLoginUser_Fail() {
        loginApp.registerUser("user_", "StrongP@ss1", "+27839123456");
        assertFalse(loginApp.loginUser("user_", "WrongPass"), "Login should fail.");
    }
}
}
