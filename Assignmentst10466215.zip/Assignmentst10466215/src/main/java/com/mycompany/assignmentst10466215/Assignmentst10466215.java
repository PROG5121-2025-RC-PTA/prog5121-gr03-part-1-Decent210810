/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignmentst10466215;

/**
 *
 * @author nuker
 */



import java.util.Scanner;

public class Assignmentst10466215 {

    public static void main(String[] args) {
      
Scanner scanner = new Scanner(System.in);
        Login loginApp = new Login();
        System.out.println("Welcome to the Registration Portal");
        
        // Ask for name
        System.out.print("Put in your first name: ");
        loginApp.firstName = scanner.nextLine();
        
        System.out.print("Put in your last name: ");
        loginApp.lastName = scanner.nextLine();
        
        // Registration
        System.out.print("Enter username (must contain _ and be 5 characters max): ");
        String user = scanner.nextLine();
        
        System.out.print("Enter password (8+ chars, capital letter, number, special char): ");
        String pass = scanner.nextLine();
        
        System.out.print("Enter your cell phone number (with +27): ");
        String cell = scanner.nextLine();
        
        String regMessage = loginApp.registerUser(user, pass, cell);
        System.out.println(regMessage);
        
        if (regMessage.equals("User successfully registered.")) {
            // Login
            System.out.print("Enter username: ");
            String loginUser = scanner.nextLine();
            
            System.out.print("Enter password: ");
            String loginPass = scanner.nextLine();
            
            boolean isLoggedIn = loginApp.loginUser(loginUser, loginPass);
            System.out.println(loginApp.returnLoginStatus(isLoggedIn));
        }
        
        scanner.close();
    }
}