/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignmentst10466215;

/**
 *
 * @author nuker
 */


import java.util.regex.Pattern;
public class Login {
    
    public String username;
    public String password;
    public String cellPhoneNumber;
    public String firstName;
    public String lastName;
    private boolean loggedIn;

    // Constructor
    public Login() {
        this.loggedIn = false;
    }

    // Method to check if username is valid
    public boolean checkUserName() {
        // Check if username contains an underscore and is no more than 5 characters
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // Method to check if password meets complexity requirements
    public boolean checkPasswordComplexity() {
        // Check if password is null or empty
        if (password == null || password.isEmpty()) {
            return false;
        }

        // Check if password is at least 8 characters long
        if (password.length() < 8) {
            return false;
        }

        // Check if password contains a capital letter
        boolean hasCapital = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
                break;
            }
        }
        if (!hasCapital) {
            return false;
        }

        // Check if password contains a number
        boolean hasNumber = false;
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                hasNumber = true;
                break;
            }
        }
        if (!hasNumber) {
            return false;
        }

        // Check if password contains a special character
        boolean hasSpecial = false;
        String specialChars = "!@#$%^&*()_-+=<>?/[]{}|:;";
        for (char c : password.toCharArray()) {
            if (specialChars.contains(String.valueOf(c))) {
                hasSpecial = true;
                break;
            }
        }
        return hasSpecial;
    }

    // Method to check if cell phone number is valid
    public boolean checkCellPhoneNumber() {
        // Cell phone must start with +27 (South African country code) and be followed by 9 digits
        if (cellPhoneNumber == null) {
            return false;
        }
        
        // Using regular expression to check cell phone format
        // Reference: Generated with assistance from OpenAI's ChatGPT on April 14, 2025
        // Format: Must start with +27 followed by 9 digits
        return cellPhoneNumber.matches("\\+27\\d{9}");
    }

    // Method to register a user - overloaded version with parameters
    public String registerUser(String username, String password, String cellPhoneNumber) {
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
        
        return registerUser();
    }

    // Method to register a user
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {
            return "Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again.";
        }

        return "User successfully registered.";
    }

    // Method to verify login details
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        if (username != null && password != null && 
            username.equals(enteredUsername) && 
            password.equals(enteredPassword)) {
            loggedIn = true;
            return true;
        }
        loggedIn = false;
        return false;
    }

    // Method to return login status message with parameter
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + firstName + " ," + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Method to return login status message without parameter (uses class state)
    public String returnLoginStatus() {
        return returnLoginStatus(loggedIn);
    }
}