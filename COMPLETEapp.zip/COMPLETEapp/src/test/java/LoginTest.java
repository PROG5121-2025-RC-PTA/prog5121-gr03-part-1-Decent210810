/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.completeapp.Login;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author nuker
 */
public class LoginTest {
    
     Login loginApp;

    @BeforeEach
    public void setup() {
        loginApp = new Login();
    }

    @Test
    public void testRegisterUser_ValidData() {
        String result = loginApp.registerUser("john_doe", "Password1@", "+27712345678");
        assertEquals("User successfully registered.", result);
    }

    @Test
    public void testRegisterUser_InvalidUsername() {
        String result = loginApp.registerUser("john", "Password1@", "+27712345678");
        assertEquals("Username must contain '_' and be 5 characters max", result);
    }

    @Test
    public void testRegisterUser_InvalidPassword() {
        String result = loginApp.registerUser("john_doe", "password", "+27712345678");
        assertEquals("Password must contain at least 8 characters, 1 uppercase letter, 1 number, and 1 special character", result);
    }

    @Test
    public void testRegisterUser_InvalidCell() {
        String result = loginApp.registerUser("john_doe", "Password1@", "+278123");
        assertEquals("Invalid cell number. Must start with +27 and have 9 digits", result);
    }

    @Test
    public void testLoginUser_SuccessfulLogin() {
        loginApp.registerUser("john_doe", "Password1@", "+27712345678");
        boolean result = loginApp.loginUser("john_doe", "Password1@");
        assertTrue(result);
    }

    @Test
    public void testLoginUser_FailedLogin() {
        loginApp.registerUser("john_doe", "Password1@", "+27712345678");
        boolean result = loginApp.loginUser("john_doe", "WrongPassword");
        assertFalse(result);
    }
}