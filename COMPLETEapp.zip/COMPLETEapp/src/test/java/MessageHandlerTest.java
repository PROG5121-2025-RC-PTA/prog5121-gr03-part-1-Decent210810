/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.completeapp.MessageHandler;
import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author nuker
 */
public class MessageHandlerTest {
    
     MessageHandler messageHandler;

    @BeforeEach
    public void setup() {
        messageHandler = new MessageHandler();
    }

    @Test
    public void testSendMessage_Success() {
        messageHandler.sendMessage("john_doe", "jane_doe", "Hello, how are you?");
        ArrayList<String> sentMessages = messageHandler.sentMessagesMap.get("john_doe");
        assertNotNull(sentMessages);
        assertEquals(1, sentMessages.size());
        assertTrue(sentMessages.get(0).contains("To: jane_doe"));
    }

    @Test
    public void testSendMessage_MessageLimit() {
        messageHandler.sendMessage("john_doe", "jane_doe", "Message 1");
        messageHandler.sendMessage("john_doe", "jane_doe", "Message 2");
        messageHandler.sendMessage("john_doe", "jane_doe", "Message 3"); // Exceeds the limit

        ArrayList<String> sentMessages = messageHandler.sentMessagesMap.get("john_doe");
        assertNotNull(sentMessages);
        assertEquals(2, sentMessages.size(), "Message limit should be 2.");
    }

    @Test
    public void testViewSentMessages_Empty() {
        messageHandler.viewSentMessages("john_doe");  // No messages sent yet.
        // This test is just to check the proper handling of no messages.
    }

    @Test
    public void testDeleteSentMessage() {
        messageHandler.sendMessage("john_doe", "jane_doe", "Message 1");
        messageHandler.sendMessage("john_doe", "jane_doe", "Message 2");

        messageHandler.deleteSentMessage("john_doe", 0);  // Delete first message

        ArrayList<String> sentMessages = messageHandler.sentMessagesMap.get("john_doe");
        assertNotNull(sentMessages);
        assertEquals(1, sentMessages.size(), "One message should be deleted.");
        assertFalse(sentMessages.get(0).contains("Message 1"), "Message 1 should be deleted.");
    }

    @Test
    public void testDeleteSentMessage_InvalidIndex() {
        messageHandler.sendMessage("john_doe", "jane_doe", "Message 1");
        messageHandler.deleteSentMessage("john_doe", 10);  // Invalid index

        ArrayList<String> sentMessages = messageHandler.sentMessagesMap.get("john_doe");
        assertNotNull(sentMessages);
        assertEquals(1, sentMessages.size(), "Message should not be deleted due to invalid index.");
    }
}