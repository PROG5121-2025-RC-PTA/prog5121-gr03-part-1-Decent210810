/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.completeapp;

/**
 *
 * @author nuker
 */
import java.util.ArrayList;
import java.util.Scanner;

public class COMPLETEapp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login loginApp = new Login();
        MessageHandler messageHandler = new MessageHandler();

        System.out.println("Welcome to the QuickChat Application!");

        // === REGISTRATION LOOP ===
        System.out.print("Enter your first name: ");
        loginApp.firstName = scanner.nextLine();
        System.out.print("Enter your last name: ");
        loginApp.lastName = scanner.nextLine();

        while (true) {
            System.out.print("Enter a username (must contain '_' and be 5 characters max): ");
            String user = scanner.nextLine();
            System.out.print("Enter a password (8+ chars, capital, number, special char): ");
            String pass = scanner.nextLine();
            System.out.print("Enter your cell number (+27xxxxxxxxx): ");
            String cell = scanner.nextLine();

            String regMsg = loginApp.registerUser(user, pass, cell);
            System.out.println(regMsg);
            if (regMsg.equals("User successfully registered.")) break;
            System.out.println("-- Please try registering again --\n");
        }

        // === LOGIN LOOP ===
        while (true) {
            System.out.print("Enter username to login: ");
            String u = scanner.nextLine();
            System.out.print("Enter password to login: ");
            String p = scanner.nextLine();
            if (loginApp.loginUser(u, p)) break;
            System.out.println("Invalid login credentials. Try again.\n");
        }
        System.out.println(loginApp.returnLoginStatus());

        // === ASK HOW MANY MESSAGES THE USER WANTS TO SEND ===
        System.out.print("How many messages would you like to send this session? ");
        int limit;
        while (true) {
            try {
                limit = Integer.parseInt(scanner.nextLine());
                if (limit > 0) break;
            } catch (NumberFormatException ignored) {}
            System.out.print("Enter a positive number: ");
        }
        int sentCount = 0;

        // === MAIN CHAT MENU (Rubric‑aligned) ===
        ArrayList<String> sentMessages = new ArrayList<>();
        ArrayList<String> inbox = new ArrayList<>(); // 🔹 Added inbox list
        int choice;
        do {
            System.out.println("\nChoose one of the following:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Delete Message");
            System.out.println("4) Search Messages");
            System.out.println("5) Quit");
            System.out.print("Enter choice: ");
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                choice = -1;
            }

            switch (choice) {
                case 1 -> {
                    if (sentCount >= limit) {
                        System.out.println("You have reached your message limit (" + limit + ").");
                        break;
                    }
                    // Prompt for recipient cell number and message with validation
                    String to;
                    while (true) {
                        System.out.print("Enter recipient cell number (+27xxxxxxxxx): ");
                        to = scanner.nextLine();
                        if (isValidCellNumber(to)) break;
                        System.out.println("Invalid cell number. Must start with +27 and have 9 digits.");
                    }

                    System.out.print("Enter message: ");
                    String msg = scanner.nextLine();
                    messageHandler.sendMessage(loginApp.username, to, msg);
                    String fullMessage = "To: " + to + " | " + msg;
                    sentMessages.add(fullMessage);
                    inbox.add("From: " + loginApp.username + " | " + msg); // 🔹 Simulate inbox delivery
                    sentCount++;
                    System.out.println("Message sent to " + to + ".");
                }
                case 2 -> {
                    if (sentMessages.isEmpty()) {
                        System.out.println("No messages sent yet.");
                    } else {
                        System.out.println("Sent Messages:");
                        for (int i = 0; i < sentMessages.size(); i++) {
                            System.out.println((i + 1) + ". " + sentMessages.get(i));
                        }
                    }
                    System.out.println("\nFeature coming soon.");

                    // 🔹 Display inbox
                    if (inbox.isEmpty()) {
                        System.out.println("Inbox is empty.");
                    } else {
                        System.out.println("Inbox:");
                        for (String m : inbox) {
                            System.out.println("- " + m);
                        }
                    }
                }
                case 3 -> {
                    if (sentMessages.isEmpty()) {
                        System.out.println("No messages to delete.");
                    } else {
                        System.out.println("Enter message index to delete (1 to " + sentMessages.size() + "): ");
                        int index;
                        try {
                            index = Integer.parseInt(scanner.nextLine());
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid input.");
                            break;
                        }
                        if (index > 0 && index <= sentMessages.size()) {
                            sentMessages.remove(index - 1);
                            sentCount--; // Allow sending one more if one is deleted
                            System.out.println("Message deleted.");
                        } else {
                            System.out.println("Invalid index.");
                        }
                    }
                }
                case 4 -> {
                    if (sentMessages.isEmpty()) {
                        System.out.println("No messages to search.");
                    } else {
                        System.out.print("Enter keyword to search: ");
                        String keyword = scanner.nextLine().toLowerCase();
                        boolean found = false;
                        for (String message : sentMessages) {
                            if (message.toLowerCase().contains(keyword)) {
                                System.out.println("- " + message);
                                found = true;
                            }
                        }
                        if (!found) {
                            System.out.println("No matching messages found.");
                        }
                    }
                }
                case 5 -> System.out.println("Goodbye!");
                default -> System.out.println("Invalid option. Try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    public static boolean isValidCellNumber(String cell) {
        return cell.startsWith("+27") && cell.length() == 12 && cell.substring(3).matches("\\d{9}");
    }
}