/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.completeapp;

/**
 *
 * @author nuker
 */
public class Login {
    
      public String username;
    public String password;
    public String firstName;
    public String lastName;
    public String cell;

    // Method to register a user with username, password, and cell number
    public String registerUser(String username, String password, String cell) {
        // Check if the username contains "_" and is 5 characters max
        if (!username.contains("_") || username.length() > 5) {
            return "Username is not correctly formatted.";
        }

        // Validate the password format
        if (!isValidPassword(password)) {
            return "Password is not correctly formatted.";
        }

        // Validate the cell number format (must start with +27 and have 9 digits)
        if (!isValidCellNumber(cell)) {
            return "Invalid cell number. Must start with +27 and have 9 digits.";
        }

        // If all checks pass, assign values to instance variables
        this.username = username;
        this.password = password;
        this.cell = cell;

        return "User successfully registered.";
    }

    // Method to validate login credentials (username and password)
    public boolean loginUser(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    // Method to return a custom login success message
    public String returnLoginStatus() {
        return "Welcome " + firstName + " " + lastName + ", it is great to see you again!";
    }

    // Method to validate the password based on specific rules (min length, capital letter, number, special char)
    public boolean isValidPassword(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&  // At least one capital letter
               password.matches(".*[a-z].*") &&  // At least one lowercase letter
               password.matches(".*\\d.*") &&    // At least one digit
               password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?].*");  // At least one special character
    }

    // Method to validate a cell number (must start with +27 and have exactly 9 digits)
    public boolean isValidCellNumber(String cell) {
        return cell.startsWith("+27") && cell.length() == 12 && cell.substring(3).matches("\\d{9}");
    }
}