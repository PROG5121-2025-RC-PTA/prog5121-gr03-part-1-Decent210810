/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.completeapp;

/**
 *
 * @author nuker
 */
import java.util.*;
import java.util.Scanner;

public class MessageHandler {
    
     public HashMap<String, ArrayList<String>> sentMessagesMap = new HashMap<>();
    
    public void sendMessage(String sender, String recipient, String messageText) {
        String fullMessage = "To: " + recipient + " | Message: " + messageText;
        
        sentMessagesMap.putIfAbsent(sender, new ArrayList<>());
        sentMessagesMap.get(sender).add(fullMessage);
        
        System.out.println("\nMessage sent to " + recipient + ".");
    }
    
    public void viewSentMessages(String sender) {
        ArrayList<String> messages = sentMessagesMap.get(sender);
        
        if (messages == null || messages.isEmpty()) {
            System.out.println("\nNo sent messages found.");
            return;
        }
        
        System.out.println("\nSent Messages:");
        for (int i = 0; i < messages.size(); i++) {
            System.out.println((i + 1) + ". " + messages.get(i));
        }
    }
    
    public void deleteSentMessage(String sender, int index) {
        ArrayList<String> messages = sentMessagesMap.get(sender);
        
        if (messages == null || index < 0 || index >= messages.size()) {
            System.out.println("\nInvalid message index.");
            return;
        }
        
        messages.remove(index);
        System.out.println("\nMessage deleted successfully.");
    }
    
    public void searchSentMessages(String sender, String keyword) {
        ArrayList<String> messages = sentMessagesMap.get(sender);
        
        if (messages == null || messages.isEmpty()) {
            System.out.println("\nNo messages to search.");
            return;
        }
        
        System.out.println("\nSearch Results for \"" + keyword + "\":");
        boolean found = false;
        for (String msg : messages) {
            if (msg.toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println("- " + msg);
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No matching messages found.");
        }
    }
}